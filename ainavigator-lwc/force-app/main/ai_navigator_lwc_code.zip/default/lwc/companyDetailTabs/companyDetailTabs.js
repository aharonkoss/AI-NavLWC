/**
 * @description companyDetailTabs
 * Top-level tab strip - aligned with React web app navigation.
 * Tabs: Research | Signals | Insights | Call Plan | Coach | Simulator
 * NOTE: "Updates" tab removed to match React app. Default is "research".
 *
 * @group AI Navigator - LWC
 * @last-modified 2026-05-08
 */
import { LightningElement, api } from 'lwc';

const ALL_TABS = [
    { id: 'research',  label: 'Research'     },
    { id: 'signals',   label: 'Signals'      },
    { id: 'insights',  label: 'Insights'     },
    { id: 'callplan',  label: 'Call Plan'    },
    { id: 'coach',     label: '🎧 Coach'     },
    { id: 'simulator', label: '🎮 Simulator' }
];

export default class CompanyDetailTabs extends LightningElement {

    @api activeTab = 'research'; // default matches React

    get tabs() {
        return ALL_TABS.map(t => ({
            ...t,
            cls: t.id === this.activeTab ? 'cdt-tab cdt-tab-active' : 'cdt-tab'
        }));
    }

    handleClick(event) {
        const tab = event.currentTarget.dataset.tab;
        this.dispatchEvent(new CustomEvent('tabchange', { detail: { tab } }));
    }
}