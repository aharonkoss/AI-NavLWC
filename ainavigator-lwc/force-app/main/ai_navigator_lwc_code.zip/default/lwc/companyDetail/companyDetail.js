/**
 * @description companyDetail
 * @last-modified 2026-05-08
 */
import { LightningElement, api, track, wire } from 'lwc';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
import { subscribe, unsubscribe, onError } from 'lightning/empApi';
import getCompany     from '@salesforce/apex/CompanyDetailController.getCompany';
import getLiveUpdates from '@salesforce/apex/CompanyDetailController.getLiveUpdates';
import getSignals     from '@salesforce/apex/CompanyDetailController.getSignals';

const CHANNEL = '/event/AINavigatorInbound__e';

export default class CompanyDetail extends NavigationMixin(LightningElement) {

    // -------------------------------------------------------------------------
    // Public API — needed so HTML template binding compiles
    // -------------------------------------------------------------------------
    @api companyId;  // set by Lightning App Builder if placed on a page directly

    // -------------------------------------------------------------------------
    // Internal state — use _resolvedCompanyId everywhere internally
    // -------------------------------------------------------------------------
    @track _resolvedCompanyId    = null;  // ← internal resolved ID from URL or @api
    @track company               = null;
    @track liveUpdates           = null;
    @track signalsData           = null;
    @track aiResearch            = null;
    @track discoveryCallPlanData = null;
    @track activeTab             = 'research';
    @track isLoading             = true;
    @track error                 = null;
    subscription                 = null;

    // -------------------------------------------------------------------------
    // Wire: read companyId from URL state
    // -------------------------------------------------------------------------
    @wire(CurrentPageReference)
    handlePageRef(pageRef) {
        const idFromState = pageRef?.state?.c__companyId
                         || pageRef?.state?.c_companyId
                         || pageRef?.state?.companyId;

        console.log('🔍 [CompanyDetail] pageRef.state:', JSON.stringify(pageRef?.state));
        console.log('🔍 [CompanyDetail] resolved companyId:', idFromState);

        const resolved = idFromState || this.companyId;

        if (resolved && resolved !== this._resolvedCompanyId) {
            this._resolvedCompanyId = resolved;
            this.loadCompanyData(resolved);
        }
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------
    connectedCallback() {
        this.registerEmpErrorHandler();
        this.subscribeToInbound();
    }

    disconnectedCallback() {
        this.unsubscribeFromInbound();
    }

    // -------------------------------------------------------------------------
    // Data load
    // -------------------------------------------------------------------------
    loadCompanyData(id) {
        this.isLoading = true;
        this.error = null;
        Promise.all([
            getCompany({ companyId: id }),
            getLiveUpdates({ companyId: id }),
            getSignals({ companyId: id })
        ])
        .then(([companyJson, updatesJson, signalsJson]) => {
            this.company     = JSON.parse(companyJson);
            this.liveUpdates = JSON.parse(updatesJson);
            this.signalsData = JSON.parse(signalsJson);
            this.isLoading   = false;
        })
        .catch(err => {
            console.error('CompanyDetail load error', err);
            this.error = err?.body?.message || 'Failed to load company data.';
            this.isLoading = false;
        });
    }

    // -------------------------------------------------------------------------
    // EMP subscription
    // -------------------------------------------------------------------------
    subscribeToInbound() {
        if (this.subscription) return;
        subscribe(CHANNEL, -1, (event) => this.handleInboundEvent(event))
            .then(sub => {
                this.subscription = sub;
                console.log('CompanyDetail subscribed to', CHANNEL);
            })
            .catch(err => {
                console.warn('CompanyDetail empApi subscribe unavailable (403). Real-time updates disabled.', err);
            });
    }

    unsubscribeFromInbound() {
        if (!this.subscription) return;
        unsubscribe(this.subscription, result => {
            console.log('CompanyDetail unsubscribed from', CHANNEL, result);
            this.subscription = null;
        });
    }

    registerEmpErrorHandler() {
        onError(error => {
            console.warn('CompanyDetail empApi error (non-fatal):', JSON.stringify(error));
        });
    }

    // -------------------------------------------------------------------------
    // Inbound event routing
    // -------------------------------------------------------------------------
    handleInboundEvent(event) {
        const data    = event?.data?.payload;
        const evtType = data?.EventType__c;
        if (!evtType) return;

        let payload;
        try {
            payload = data.Payload__c ? JSON.parse(data.Payload__c) : {};
        } catch (e) {
            console.error('CompanyDetail failed to parse Payload__c', e);
            return;
        }

        const sfIdMatch    = payload.salesforceId && payload.salesforceId === this._resolvedCompanyId;
        const azureIdMatch = payload.companyId && this.company?.AzureCompanyId__c &&
                             payload.companyId === this.company.AzureCompanyId__c;
        if (!sfIdMatch && !azureIdMatch) return;

        switch (evtType) {
            case 'RESEARCH_DONE':
                this.loadCompanyData(this._resolvedCompanyId);
                break;
            case 'PROCESSING_ERROR':
                this.error = payload.message || 'An error occurred during processing.';
                break;
            case 'SIGNAL_ALERT':
                this.routeSignalAlert(payload);
                break;
            default:
                break;
        }
    }

    routeSignalAlert(payload) {
        const signalsComp = this.template.querySelector('c-company-detail-signals');
        if (signalsComp) {
            signalsComp.refreshSignals(payload);
        } else {
            const existing = this.signalsData?.signals || [];
            const incoming = payload.signals || [];
            this.signalsData = { ...this.signalsData, signals: [...incoming, ...existing] };
        }
    }

    // -------------------------------------------------------------------------
    // Computed
    // -------------------------------------------------------------------------
    get hasCompany()    { return !!this._resolvedCompanyId; }
    get companyName()   { return this.company?.name || this.company?.Name; }

    get showResearch()  { return this.activeTab === 'research';  }
    get showSignals()   { return this.activeTab === 'signals';   }
    get showInsights()  { return this.activeTab === 'insights';  }
    get showCallPlan()  { return this.activeTab === 'callplan';  }
    get showCoach()     { return this.activeTab === 'coach';     }
    get showSimulator() { return this.activeTab === 'simulator'; }

    // -------------------------------------------------------------------------
    // Handlers
    // -------------------------------------------------------------------------
    handleTabChange(event) {
        this.activeTab = event.detail.tab;
    }

    handleBackToDashboard() {
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: { apiName: 'AI_Navigator' }
        });
    }

    handleDownloadPDF() {
        if (this.showSignals)  { this.template.querySelector('c-company-detail-signals')?.handleDownloadPDF(); }
        if (this.showCallPlan) { this.template.querySelector('c-company-detail-call-plan')?.handleDownloadPDF(); }
    }
}